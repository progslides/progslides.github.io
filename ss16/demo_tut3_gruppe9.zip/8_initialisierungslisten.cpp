#include <iostream>

class Coordinate 
{
  private:
    int x_, y_;

  public:
    Coordinate(std::initializer_list<int> list) 
    {
      auto values = list.begin();
      x_ = *values++;
      y_ = *values;
    }

    void setXY(std::initializer_list<int> list) 
    {
      auto values = list.begin();
      x_ = *values++;
      y_ = *values;
    }

    int getX() { return x_; }
    int getY() { return y_; }
};

int main() {
  Coordinate start = {3, 4};
  start.setXY({1, 2});
  std::cout << start.getX() << "," << start.getY() << std::endl;
}
