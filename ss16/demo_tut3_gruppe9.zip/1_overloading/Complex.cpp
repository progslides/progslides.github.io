// Complex.cpp
#include "Complex.h"

Complex::Complex() : real_part_(0.0), imag_part_(0.0)
{

}

float Complex::getRealPart() const
{
  return real_part_;
}

float Complex::getImagPart() const
{
  return imag_part_;
}

void Complex::setRealPart(float real_part)
{
  real_part_ = real_part;
}

void Complex::setImagPart(float imag_part)
{
  imag_part_ = imag_part;
}

bool Complex::operator==(const Complex &complex) const
{
  return (complex.real_part_ == real_part_ && (complex.imag_part_ == imag_part_));
}

Complex Complex::operator+(const Complex &complex)
{
  Complex result;
  result.setImagPart(imag_part_ + complex.getImagPart());
  result.setRealPart(real_part_ + complex.getRealPart());
  return result;
}

Complex::~Complex()
{

}
