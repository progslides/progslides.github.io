#include "MoveCommand.h"
#include <iostream>

int MoveCommand::execute(std::vector<std::unique_ptr<Ball> >& params)
{
  for(auto ball = params.begin(); ball != params.end(); ball++) 
  {
    (*ball)->move(1, 3);
  }
}

MoveCommand::~MoveCommand()
{
  
}