#include <iostream>
#include <cstdlib>

double divide(double numerator, double divisor)
{
  if(divisor == 0)
  {
    throw std::invalid_argument("0 as divisor!");
  }
  
  return numerator / divisor;
}

int main()
{
  int numerator, divisor_min, divisor_max;
  float result;
  float divisor;
  
  std::cout << "Type in numerator: " << std::endl;
  std::cin >> numerator;
  std::cout << "Type in upper and lower divisor range: " << std::endl;
  std::cin >> divisor_min >> divisor_max;
  
  int range = abs(divisor_max - divisor_min) + 1;
  divisor = divisor_min;
  try
  {
    for (int i = 0; i < range; i++)
    {
      result = divide(numerator, divisor);
      std::cout << result << std::endl;
      divisor++;
      std::cout << "Round: " << i << std::endl;
    }
  }
  catch(std::invalid_argument &e)
  {
    std::cout << e.what();
  }
  
  return 0;
}
