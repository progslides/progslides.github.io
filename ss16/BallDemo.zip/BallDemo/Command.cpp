#include "Command.h"

Command::Command(std::string name) : command_name_(name)
{
  
}

Command::~Command()
{
  
}

const std::string& Command::getName()
{
  return command_name_;
}