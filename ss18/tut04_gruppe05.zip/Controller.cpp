#include "Controller.h"
#include "View.h"
#include "Model.h"
//TODO: implement behaviour of application

#include "Command.h"

Controller::Controller(std::unique_ptr<View> view, std::unique_ptr<Model> model) :
	view_(std::move(view)), model_(std::move(model)), running_(true)
{

}

void Controller::initCommands()
{
	command_map_["set"] = std::unique_ptr< Command >(new SetPasswordCommand());
	command_map_["print"] = std::unique_ptr< Command >(new PrintPasswordCommand());
	command_map_["quit"] = std::unique_ptr< Command >(new QuitCommand());
	command_map_["q"] = std::unique_ptr< Command >(new QuitCommand());
}

void Controller::run()
{
	initCommands();
	while (running_)
	{

		std::vector< std::string > args = view_->parseArgsWithPrompt();

		std::string command_name;

		if (args.size() > 0)
		{
			command_name = args[0];
		}


		if (command_map_.find(command_name) != command_map_.end())
		{
			command_map_[command_name]->execute(*this, args);
		}

		


		/*if (command_name == "set")
		{
			SetPasswordCommand cmd;
			cmd.execute(*this, args);
		}
		else if (command_name == "print")
		{
			PrintPasswordCommand cmd;
			cmd.execute(*this, args);
		}
		else if (command_name == "quit")
		{
			QuitCommand cmd;
			cmd.execute(*this, args);
		}*/

	}
}

void Controller::outputToView(std::string output)
{
	view_->outputMessage(output);
}

void Controller::setPassword(std::string new_password)
{
	model_->setPassword(new_password);
}

std::string Controller::getPassword()
{
	return model_->getPassword();
}

void Controller::quit()
{
	running_ = false;
}