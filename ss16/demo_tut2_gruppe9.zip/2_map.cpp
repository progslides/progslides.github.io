#include <iostream>
#include <map>
#include <string>

int main()
{
  std::map<std::string, double> constants;
  constants["pi"] = 3.1415926536;
  constants["e"] = 2.7182818284;
  constants["phi"] = 2.61803398875;

  // find a single entry
  auto it = constants.find("pi");
  if (it != constants.end())
  {
    std::cout << it->first << " = " << it->second << std::endl;
  }

  // list all entries
  for (it = constants.begin(); it != constants.end(); it++)
  {
    std::cout << it->first << " = " << it->second << std::endl;
  }
}
