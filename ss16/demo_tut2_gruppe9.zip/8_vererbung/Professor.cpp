// Person.cpp
#include <iostream>
#include "Professor.h"

Professor::Professor()
{

}

Professor::Professor(std::string name) : Person(name)
{

}

void Professor::printData()
{
  std::cout << "I am a professor!" << std::endl;
}

Professor::~Professor()
{

}
   
