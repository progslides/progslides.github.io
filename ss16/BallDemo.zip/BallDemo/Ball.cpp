// Ball.cpp
#include "Ball.h"
#include <iostream>

Ball::Ball(std::string color) : color_(color), x_(0), y_(0)
{
  memory = new int[10000];
  
  std::cout << "Ball ("<< color << ") constructor" << std::endl;
}
void Ball::move(double dx, double dy)
{
  x_ += dx;
  y_ += dy;
  
  std::cout << "Ball moved" << std::endl;
}
std::string Ball::getColor()
{
  return color_;
}
void Ball::setColor(std::string new_color)
{
  color_ = new_color;
}

Ball::Ball() : color_("yellow"), x_(0), y_(0)
{
  memory = new int[10000];
  
  std::cout << "Ball empty constructor" << std::endl;
} 

Ball::~Ball()
{
  delete[] memory;
  std::cout << "Ball destructor" << std::endl;
}