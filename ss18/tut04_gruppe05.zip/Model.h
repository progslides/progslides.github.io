#ifndef MODEL_H
#define MODEL_H

#include <string>


class Model
{
public:
	void setPassword(std::string new_password);
	std::string getPassword();

private:
	std::string password_;
};

#endif
