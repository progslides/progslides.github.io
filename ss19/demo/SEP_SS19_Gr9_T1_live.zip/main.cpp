#include <iostream>
#include "Safe.h"

int main()
{
  std::string password;
  std::cin >> password;
  Safe safe(123);
  safe.savePassword(password);
  int pin;
  std::cin >> pin;
  std::cout << safe.getPassword(pin);

  return 0;
}