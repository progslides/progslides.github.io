/*
Beschreibung: Lese Zahlen von stdin in einen vector ein, Abbruchbedingung: -1
sortiere die Zahlen im vector aufsteigend
schreibe die Zahlen in ein File
lese die Zahlen aus dem File
*/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>  


void read(std::string filename)
{
  std::string line;
  std::ifstream input(filename.c_str(), std::ios::in);
  if (!input.is_open()) //Kontrolle, ob Fehler
  {
    std::cout << "cannot open file" << std::endl;
  } 
  else 
  {
    while(std::getline(input,line)) //get lines
    {
      std::cout << line << std::endl;
    }
    input.close(); 
  }
}

void write(std::vector<int> &input, std::string filename)
{
  std::ofstream file(filename.c_str(), std::ios::out | std::ios::app);
  if (!file.is_open())//Kontrolle, ob Fehler
  {
    std::cout << "cannot open file" << std::endl;
  } 
  else 
  {
    for(auto it = input.begin(); it != input.end(); it++)
    {
      file << *it;
    }
    file.close(); 
  }
}

int main()
{

  std::vector<int> int_list;
  int input = 0;
  
  std::cin >> input;
  while(input != -1)
  {
    int_list.push_back(input);
    std::cin >> input;     
  }
  
  std::sort(int_list.begin(), int_list.end());
  write(int_list, "test_file"); 
  read("test_file");
  
  return 0;
}
