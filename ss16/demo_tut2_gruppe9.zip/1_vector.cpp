#include <iostream>
#include <vector>
int main()
{
  std::vector<int> list;
  int input = 0;
  
  std::cin >> input;
  while(input != -1)
  {
    list.push_back(input);
    std::cin >> input;     
  }
  
  for(auto it = list.begin(); it != list.end(); it++)
  {
    cout << *it << endl;
  }
  return 0;
}
