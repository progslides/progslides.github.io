#ifndef SEP_INVALIDPASSWORDEXCEPTION_H
#define SEP_INVALIDPASSWORDEXCEPTION_H

#include <exception>
#include <iostream>

class InvalidPasswordException : public std::exception
{
  private:
    static const std::string msg;
    int length;

  public:
    InvalidPasswordException() = delete;
    InvalidPasswordException(std::string const& password, int min_length);

    friend std::ostream& operator<<(std::ostream& stream,
      const InvalidPasswordException& exception);
    virtual const char* what() const noexcept override;

};

#endif //SEP_INVALIDPASSWORDEXCEPTION_H
