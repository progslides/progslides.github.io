#ifndef SEP_SAFE_H
#define SEP_SAFE_H

#include <vector>
#include <iostream>
#include <memory>
#include <algorithm>

namespace sep
{
  template <typename T>
  class Safe
  {
    private:
      static size_t safe_counter;
      const size_t safeId;
      std::vector<T> passwords;
      std::shared_ptr<std::string> masterPassword;

    public:
      Safe(std::string& masterPassword);
      virtual ~Safe() noexcept;
      virtual void savePassword(T const& password);
      void printPasswords(std::string const& masterPassword) const;
      bool containsPassword(std::string const& masterPassword,
        T const& password) const;
  };

  template <typename T>
  size_t Safe<T>::safe_counter = 0;

  template <typename T>
  void Safe<T>::savePassword(T const& password)
  {
    passwords.push_back(password);
  }

  template <typename T>
  void Safe<T>::printPasswords(std::string const& masterPassword) const
  {
    if(*((*this).masterPassword) == masterPassword)
    {
      //std::cout << ">>> Print passwords using range-based loop ..." << std::endl;
      //use const reference as range-based loop -> best in this case
      for (T const &password : passwords)
      {
        std::cout << password << std::endl;
      }
    }
    else
    {
      std::cout << "Fehler" << std::endl;
    }
  }

  template <typename T>
  Safe<T>::Safe(std::string& masterPassword) : safeId(++safe_counter)
  {
    std::cout << ">> Construct safe " << safeId << std::endl;
    this->masterPassword = std::make_shared<std::string>(masterPassword);
  }

  template <typename T>
  Safe<T>::~Safe() noexcept
  {
    std::cout << ">> Destruct safe " << safeId << std::endl;
    //delete masterPassword;
  }

  template <typename T>
  bool Safe<T>::containsPassword(
    std::string const& masterPassword, T const& password) const
  {
    if(*((*this).masterPassword) != masterPassword)
    {
      return false;
    }

    //for (auto const& pw : passwords)
    //{
    //    if (pw == password)
    //      return true;
    //  }
    //return false;

    return std::any_of(passwords.begin(), passwords.end(),
      [&password](T const& pw){
        return password == pw;
      });
  }

}
#endif //SEP_SAFE_H
