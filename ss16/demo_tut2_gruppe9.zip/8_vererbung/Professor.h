#ifndef Professor_H_INCLUDED
#define Professor_H_INCLUDED
#include <string>
#include "Person.h"


class Professor : public Person //Klasse
{
private:
  
public:
  Professor();
  Professor(std::string name);
  
  void printData(); //Methoden
  
  virtual ~Professor(); //Destruktor
};
#endif
