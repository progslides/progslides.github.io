#include "Command.h"
#include "Controller.h"

void SetPasswordCommand::execute(Controller& controller, std::vector<std::string> args)
{
	//TODO: set password
	controller.setPassword(args[1]);
}


void PrintPasswordCommand::execute(Controller& controller, std::vector<std::string> args)
{
	//TODO: print password to view
	controller.outputToView(controller.getPassword() + '\n');
}

void QuitCommand::execute(Controller& controller, std::vector<std::string> args)
{
	//TODO: quit the MVC app

	controller.quit();
}