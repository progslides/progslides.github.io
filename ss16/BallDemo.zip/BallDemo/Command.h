#ifndef COMMAND

#define COMMAND
#include <memory>
#include "Ball.h"
#include <vector>
class Command
{
  private:
    Command(const Command& original);
    Command& operator=(const Command& original);

    std::string command_name_;

  public:
    Command(std::string name);
    virtual ~Command();

    virtual int execute(std::vector<std::unique_ptr<Ball> >& params) = 0;

    const std::string& getName();
};

#endif