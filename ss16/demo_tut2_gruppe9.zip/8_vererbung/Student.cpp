// Person.cpp
#include <iostream>
#include "Student.h"

Student::Student()
{

}

Student::Student(std::string name) : Person(name)
{

}

void Student::printData()
{
  std::cout << "I am a Student!" << std::endl;
}

Student::~Student()
{

}
   
