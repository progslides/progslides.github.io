#include <iostream>
#include <string>
#include "Complex.h"

int main()
{
  Complex comp1;
  Complex comp2;
  Complex comp3;
  
  comp1.setRealPart(2.0);
  comp1.setImagPart(1.0);
  
  comp2.setRealPart(4.0);
  comp2.setImagPart(2.0);
  
  comp3 = comp1 + comp1;
  if(comp3 == comp2)
    std::cout << "Comp3 is Comp2" << std::endl;
  else
    std::cout << "Do not match" << std::endl;

  return 0;
}
