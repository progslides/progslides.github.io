#include "Safe.h"
#include <iostream>

using std::string;

using sep::Safe;

size_t Safe::safe_counter = 0;

void Safe::savePassword(string const& password)
{
  passwords.push_back(password);
}

void Safe::printPasswords(std::string const& masterPassword) const
{
  if(*((*this).masterPassword) == masterPassword)
  {
    //using const_iterator here to not copy vector
    std::cout << ">>> Print passwords using fully declared iterator ..." << std::endl;
    for (std::vector<string>::const_iterator it = passwords.begin() ; it != passwords.end(); ++it)
    {
      std::cout << *it << std::endl;
    }
    std::cout << ">>> Print passwords using auto iterator ..." << std::endl;
    //using auto for easier writing -> see next tutorium
    for (auto it = passwords.begin() ; it != passwords.end(); ++it)
    {
      std::cout << *it << std::endl;
    }

    std::cout << ">>> Print passwords using size-based loop ..." << std::endl;
    //use size-based loop
    for(int i = 0; i < passwords.size(); i++)
    {
      std::cout << passwords[i] << std::endl;
    }

    std::cout << ">>> Print passwords using range-based loop ..." << std::endl;
    //use const reference as range-based loop -> best in this case
    for (std::string const &password : passwords)
    {
      std::cout << password << std::endl;
    }
  }
  else
  {
    std::cout << "Fehler" << std::endl;
  }
}

Safe::Safe(string& masterPassword) : safeId(++safe_counter)
{
  std::cout << ">> Construct safe " << safeId << std::endl;
  this->masterPassword = std::make_shared<string>(masterPassword);
}

Safe::~Safe()
{
  std::cout << ">> Destruct safe " << safeId << std::endl;
  //delete masterPassword;
}