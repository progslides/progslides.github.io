#ifndef SEP_SAFERSAFE_H
#define SEP_SAFERSAFE_H

#include "Safe.h"

using sep::Safe;

class SaferSafe : public Safe<std::string>
{
  public:
    SaferSafe() = delete;
    SaferSafe(std::string &masterPassword);
    SaferSafe(SaferSafe const& saferSafe) = delete;
    SaferSafe& operator=(SaferSafe const& saferSafe) = delete;
    virtual ~SaferSafe() noexcept = default;
    void savePassword(std::string const& password) override;

};

#endif //SEP_SAFERSAFE_H
