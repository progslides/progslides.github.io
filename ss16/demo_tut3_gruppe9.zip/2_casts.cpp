#include <iostream>

void func(char *input)
{
  std::cout << input << std::endl; //input darf nicht veraendert werden durch Funktion!
}

int main()
{
  int a = 16;
  int b = 9;
  float ratio = static_cast<float>(a) / b;
  std::cout << ratio << std::endl;
  
  const char * c = "text";
  func(const_cast<char *>(c));
  
  
  float e = 42;
  int d = *reinterpret_cast<int*>(&e);  //bekommt einen int* der auf e zeigt, mit * wird der Wert dereferenziert. Liest den Speicher auf einem anderen Weg, es wird memory location gegeben und mit dem cast wird angegeben, wie der Speicher gelesen werden soll ->gefaehrlich!
  //1109917... deswegen, weil float =42 ja als 0100 0001 0100 ... dargestellt wird, wird diese binearfolge aber als int interpretiert, kommt  diese zahl raus
  
  std::cout << d << std::endl;

  return 0;
}
