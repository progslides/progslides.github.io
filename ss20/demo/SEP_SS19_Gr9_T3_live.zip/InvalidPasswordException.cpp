#include "InvalidPasswordException.h"

const std::string InvalidPasswordException::msg
  = "Es fehlen ein paar Zeichen: ";

InvalidPasswordException::InvalidPasswordException(
  std::string const& password, int min_length)
  : length(min_length - password.length())
{
}

std::ostream& operator<<(
  std::ostream& stream, const InvalidPasswordException& exception)
{
  stream << InvalidPasswordException::msg << exception.length;
  return stream;
}

const char* InvalidPasswordException::what() const noexcept
{
  return "InvalidPasswordException";
}
