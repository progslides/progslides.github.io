#ifndef COMPLEX_H_INCLUDED
#define COMPLEX_H_INCLUDED

class Complex //Klasse
{
private:
  float real_part_;
  float imag_part_;
  
public:
  Complex(); //Konstruktor
  
  float getRealPart() const; //wollen mit getter ja nichts veraendern
  float getImagPart() const;
  
  void setRealPart(float real_part);
  void setImagPart(float imag_part);
  
  bool operator==(const Complex &complex) const;
  Complex operator+(const Complex &complex);
  
  ~Complex(); //Destruktor, falls eine abgeleitete Klasse -> virtuell
};
#endif
