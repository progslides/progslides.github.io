class Data
{
private:
  int* data_;
public:
  Data(int count) 
  {
    data_ = new int[count];
  }
  
  int* getData() const 
  {
    return data_;
  }
  
  void setData(int* data, int count)
  {
    std::memcpy(data_, data,
      count * sizeof(int));
  }
  
  ~Data() 
  {
    delete[] data_;
  }
};

int median(int* numbers, int count)
{
  Data data(count);
  data.setData(numbers, count);
  // error handling
  if(numbers == NULL)
    return 0;
  if(count == 0)
    return 0;
  if(count == 1)
    return *numbers;

  // sort
  if(mySortFunction(data.getData(),
       count) == false)
    return 0;

  return data.getData()[count / 2];
}
