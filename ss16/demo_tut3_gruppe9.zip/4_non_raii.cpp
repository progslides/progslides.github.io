int median(int* numbers, int count) 
{
  int* data = new int[count];
  std::memcpy(data, numbers, count * sizeof(int));
  // error handling
  if(numbers == NULL) 
  {
    delete[] data; // <---
    return 0;
  }
  if(count == 0) 
  {
    delete[] data; // <---
    return 0;
  }
  if(count == 1) 
  {
    delete[] data; // <---
    return *numbers;
  }
  // sort
  if(mySortFunction(data, count) == false) 
  {
    delete[] data; // <---
    return 0;
  }
  // return median
  int result = data[count / 2];
  delete[] data; // <---
  return result;
}
