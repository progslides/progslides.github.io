#include "Safe.h"
#include <iostream>

using std::string;

void Safe::savePassword(string password){
  this->password = password;
}

string Safe::getPassword(int pin) const {
  if ((*this).pin == pin)
  {
    return this->password;
  }
  return "Fehler";

}

Safe::Safe(int pin):pin(pin) {

}
