#include "View.h"
#include <sstream>
#include <iostream>

void View::outputMessage(std::string& message)
{
	//TODO: output message to stdout
	std::cout << message;
}

std::vector<std::string> View::parseArgsWithPrompt()
{
	//TODO: print prompt, parse line in args
	std::cout << "septut> ";

	std::string line;
	std::getline(std::cin, line);

	std::stringstream stream(line);
	std::string arg;

	std::vector< std::string > args;


	while (stream >> arg)
	{
		args.push_back(arg);
	}

	return args;
}


FileOutputView::FileOutputView(std::string filename)
{
	file_.open(filename, std::ios::out);
}

void FileOutputView::outputMessage(std::string& message)
{
	file_ << message;
}