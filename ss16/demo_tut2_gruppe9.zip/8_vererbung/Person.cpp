// Person.cpp
#include <iostream>
#include "Person.h"

Person::Person() : name_("none"), mail_("none"), age_(0)
{

}

Person::Person(std::string name)
{
  setName(name);
}

std::string Person::getName()
{
  return name_;
}

std::string Person::getMail()
{
  return mail_;
}

int Person::getAge()
{
  return age_;
}


void Person::setName(std::string new_name)
{
  name_ = new_name;
}

void Person::setMail(std::string new_mail)
{
  mail_ = new_mail;
}

void Person::setAge(int new_age)
{
  age_ = new_age;
}

Person::~Person()
{

}
   
