#include <iostream>
#include "Safe.h"

using sep::Safe;

void createUselessSafe()
{
  std::string pw("password");
  std::shared_ptr<Safe> safe = std::make_shared<Safe>(pw);
}

int main()
{
  std::cout << "Create and test safe on stack..." << std::endl;
  std::string masterPW("master");
  Safe safe(masterPW);

  std::string password1;
  std::cout << "Please enter password 1: ";
  std::cin >> password1;
  safe.savePassword(password1);

  std::string password2;
  std::cout << "Please enter password 2: ";
  std::cin >> password2;
  safe.savePassword(password2);

  std::string pin;
  std::cout << "Enter MasterPassword: ";
  std::cin >> pin;
  safe.printPasswords(pin);


  std::cout << "Creating useless safe and destroy as stack-variable..." << std::endl;
  createUselessSafe();


  std::cout << "Create Safe in shared_ptr, copy shared_ptr, show they are the same..." << std::endl;
  std::string mpw2("master123");
  std::shared_ptr<Safe> safe2 = std::make_shared<Safe>(mpw2);
  std::shared_ptr<Safe> safe3 = safe2;
  safe3.operator->()->savePassword("mycoolpassword"); //additional null-check in operator->
  safe2.get()->printPasswords(mpw2);


  std::cout << "Create and delete safe on heap..." << std::endl;
  Safe* safe4 = new Safe(mpw2);
  delete safe4;

  std::cout << "Finished test. Returning..." << std::endl;

  return 0;
}