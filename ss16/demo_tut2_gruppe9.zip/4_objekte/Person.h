#ifndef PERSON_H_INCLUDED
#define PERSON_H_INCLUDED
#include <string>
class Person //Klasse
{
private:
  std::string name_; //Attribute
  std::string function_;
  std::string mail_;
  int age_;
  
public:
  Person();
  Person(std::string name); //Konstruktor
  
  void printData(); //Methoden

  std::string getName();
  std::string getFunction();
  std::string getMail();
  int getAge();

  void setName(std::string new_name);
  void setFunction(std::string new_function);
  void setMail(std::string new_mail);
  void setAge(int new_age);
  
  virtual ~Person(); //Destruktor
};
#endif
