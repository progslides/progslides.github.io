#include <iostream>
#include <vector>
#include <algorithm>

bool is_div5(int x) { return (x % 5 == 0); }

int main() {
  std::vector<int> numbers = {1, 3, 5, 7, 9, 11, 13};

  if(std::any_of(numbers.begin(), numbers.end(), is_div5))
  {
    std::cout << "Durch 5 teilbare Zahl gefunden" << std::endl;
  }
}
