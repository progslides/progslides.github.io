#ifndef Student_H_INCLUDED
#define Student_H_INCLUDED
#include <string>
#include "Person.h"


class Student : public Person //Klasse
{
private:
  
public:
  Student();
  Student(std::string name);
  
  void printData(); //Methoden
  
  virtual ~Student(); //Destruktor
};
#endif
