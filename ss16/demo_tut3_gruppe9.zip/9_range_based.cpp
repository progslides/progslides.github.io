#include <iostream>
#include <string>

class Test {
private:
    std::string text;

public:
    Test(std::string t) : text(t) {}

    const char* begin() {
      return text.c_str();
    }

    const char* end() {
      return text.c_str() + text.size();
    }
};

int main() {
    Test test("Test");

    for(auto t : test) {
      std::cout << t << std::endl;
    }
}
