#include <iostream>
#include <string>

class Figure
{
  private:
    int x_;
    int y_;

  public:
    void move(int x, int y);
    int getX();
    int getY();
    virtual bool isValidMove(int x, int y) = 0;
};

class Queen : public Figure
{
  public:
    bool isValidMove(int x, int y)
    {
      return true;
    }
};

class King : public Figure
{
  public:
    bool isValidMove(int x, int y)
    {
      return false;
    }
};




int main()
{
  
  King* blackKing = new King();
  King* whiteQueen = new Queen();

  std::cout << blackKing->isValidMove(1,1) << std::endl;

  std::cout << blackKing->isValidMove(3,3) << std::endl;

  std::cout << whiteQueen->isValidMove(1,1) << std::endl;

  std::cout << whiteQueen->isValidMove(3,3) << std::endl;

  delete blackKing;
  delete whiteQueen;
}
