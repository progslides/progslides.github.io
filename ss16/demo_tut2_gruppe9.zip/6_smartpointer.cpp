#include <iostream>
#include <memory>
#include <vector>

class Foo {
public:
  void bar() {
    std::cout  << "foobar" << std::endl;
  }
};

std::unique_ptr<Foo> createFoo() {
  Foo* bar = new Foo();
  return std::unique_ptr<Foo>(bar);
}

int main() {
    std::unique_ptr<Foo> ptr = createFoo();

    std::vector<std::unique_ptr<Foo>> foos;

    foos.push_back(std::unique_ptr<Foo>(new Foo()));
    foos.push_back(std::unique_ptr<Foo>(new Foo()));
    foos.push_back(std::unique_ptr<Foo>(new Foo()));
    
    foos[1]->bar();
    
    ptr->bar();
}
