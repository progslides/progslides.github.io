// BouncyBall.h
#ifndef BOUNCYBALL_H_INCLUDED
#define BOUNCYBALL_H_INCLUDED
#include <string>

#include "Ball.h"

class BouncyBall : public Ball
{


public:
  BouncyBall(std::string color);
  BouncyBall();
  void move(double dx, double dy);

};
#endif