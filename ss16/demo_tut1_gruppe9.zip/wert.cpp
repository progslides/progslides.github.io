/*
Beschreibung: Parameter sind nur Werte, aenderung der Werte innerhalb der Funktion
veraendern nicht die Werte in der main -> Werte werden kopiert
*/


#include <iostream>

void funcValue(int x, int val)
{
  x += val;
}

int main()
{
  int v = 3;
  funcValue(v, 4);
  std::cout << v << std::endl;
  
  return 0;
}
