// BouncyBall.cpp
#include "BouncyBall.h"
#include <iostream>
BouncyBall::BouncyBall(std::string color) : Ball(color)
{
  std::cout << "BouncyBall ("<< color << ") constructor" << std::endl;
}
void BouncyBall::move(double dx, double dy)
{
  x_ += dx;
  y_ += dy;
  std::cout << "BouncyBall (" << color_ << ") moved!" << std::endl;
}

BouncyBall::BouncyBall()
{
  std::cout << "BouncyBall empty constructor" << std::endl;
} 
