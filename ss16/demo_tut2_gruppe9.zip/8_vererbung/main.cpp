#include <iostream>
#include <string>
#include "Person.h"
#include "Professor.h"
#include "Student.h"

int main()
{
  Student *student1 = new Student("Pascal");
  Professor *professor1 = new Professor("Safran");
  
  professor1->printData();
  std::cout << "Name of Prof: " << professor1->getName() << std::endl;
  student1->printData();
  
  delete student1;
  delete professor1;
  
  return 0;
}
