/*
Beschreibung: kleines Beispiel mit vector.
*/

#include <vector>
#include <iostream>

int main()
{
  std::vector<int> int_vector;
  int_vector.push_back(3);
  std::cout << int_vector[0] << std::endl;
  int_vector.push_back(10);
  std::cout << "length: " << int_vector.size() << std::endl;
  
 
  return 0;
}
