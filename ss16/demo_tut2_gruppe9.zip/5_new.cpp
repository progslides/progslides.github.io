#include <iostream>

int main()
{
  int *num = new int(3);

  try
  {
    int *arr = new int[20];
  }
  catch(std::bad_alloc &ba)
  {
    std::cout << "Out of Mana!" << std::endl;
  }
  for (int i = 0; i < 20; i++)
  {
    arr[i] = 1 + i;
  }

  delete[] arr;
  delete num;
}
