#include <iostream>

class Animal
{
  
  public:
    virtual ~Animal() {};
};

class Cat : public Animal
{

};

class Dog : public Animal
{
 
};

int main()
{
  Cat *cat = new Cat;
  
  Animal *animal = cat; //upcast, because Cat is an Animal ->ok
  
  
  Cat *new_cat = dynamic_cast<Cat*>(animal); //downcast, aus Animal wird Cat
  Dog *new_dog = dynamic_cast<Dog*>(animal); //downcast, aus Animal wird Dog
  
  std::cout << new_cat << std::endl;
  std::cout << new_dog << std::endl; //liefert 0 zuerueck, da animal nicht von Typ Dog
  
  return 0;
  
}
