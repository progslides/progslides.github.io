#ifndef PERSON_H_INCLUDED
#define PERSON_H_INCLUDED
#include <string>
class Person //Klasse
{
private:
  std::string name_; //Attribute
  std::string mail_;
  int age_;
  
public:
  Person();
  Person(std::string name);
  
  virtual void printData() = 0; //virtuelle Klasse

  std::string getName();
  std::string getMail();
  int getAge();

  void setName(std::string new_name);
  void setMail(std::string new_mail);
  void setAge(int new_age);
  
  virtual ~Person(); //Destruktor
};
#endif
