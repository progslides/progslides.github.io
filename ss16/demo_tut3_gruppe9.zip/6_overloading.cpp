#include <iostream>

// volume of a cube
int volume(int s)
{
    return s*s*s;
}

// volume of a cylinder
double volume(double r, int h)
{
    return 3.14*r*r*h;
}

int main()
{
    std::cout << volume(10) << std::endl;
    std::cout << volume(2.5, 8) << std::endl;;
}
