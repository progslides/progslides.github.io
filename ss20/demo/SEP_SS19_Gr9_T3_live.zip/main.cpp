#include <iostream>
#include "Safe.h"
#include "SaferSafe.h"
#include "InvalidPasswordException.h"

using sep::Safe;

int main()
{

  std::string masterPW("master");
  SaferSafe safe(masterPW);

  std::string password;

  while(1)
  {
    try
    {
      std::cout << "Please enter safer password: ";
      std::cin >> password;
      safe.savePassword(password);
      break;
    }
    catch (InvalidPasswordException &e) //use reference!
    {
      std::cout << e.what() << " - " << e << std::endl;
    }
    catch(std::exception &e)
    {
      std::cout << "Caught general exception: " << e.what() << std::endl;
    }
  }
  safe.printPasswords(masterPW);

  std::string pw1("abc");
  std::string pw2("1234567890");
  std::cout << safe.containsPassword(masterPW, pw1) << std::endl;
  std::cout << safe.containsPassword(masterPW, pw2) << std::endl;



  Safe<int> safe1(masterPW);
  int pword1;
  std::cout << "Enter pword1 (int): ";
  std::cin >> pword1;
  safe1.savePassword(pword1);
  safe1.printPasswords(masterPW);

  std::string pword2;
  Safe<decltype(pword2)> safe2(masterPW);
  std::cout << "Enter pword2 (string): ";
  std::cin >> pword2;
  safe2.savePassword(pword2);
  safe2.printPasswords(masterPW);

  std::cout << "Finished test. Returning..." << std::endl;
  return 0;
}