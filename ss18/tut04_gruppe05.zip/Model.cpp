#include "Model.h"

void Model::setPassword(std::string new_password)
{
	password_ = new_password;
}

std::string Model::getPassword()
{
	return password_;
}