#ifndef COMMAND_H
#define COMMAND_H

#include <string>
#include <vector>

class Controller;

class Command
{
public:
	virtual void execute(Controller& controller, std::vector<std::string> args) = 0;
};

class SetPasswordCommand : public Command
{
public:
	virtual void execute(Controller& controller, std::vector<std::string> args);
};

class PrintPasswordCommand : public Command
{
public:
	virtual void execute(Controller& controller, std::vector<std::string> args);
};

class QuitCommand : public Command
{
public:
	virtual void execute(Controller& controller, std::vector<std::string> args);
};

#endif