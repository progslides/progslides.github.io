#include <iostream>
#include <vector>
#include <memory>
#include <exception>
#include "Ball.h"
#include "BouncyBall.h"
#include "Command.h"
#include "MoveCommand.h"

int main()
{
  //std::unique_ptr<Ball> ball = 
  //  std::unique_ptr<Ball>(new Ball());
    
 // std::unique_ptr<Ball> red_ball =
  //  std::unique_ptr<Ball>(new Ball("red"));
  
  
 
  //Ball* ball = new Ball();

  

 // Ball* red_ball = new Ball("red");

  //BouncyBall b_ball;
  
  //Ball* b_ball = new BouncyBall();
  
  std::vector<std::unique_ptr<Ball> > balls;
  
  balls.push_back( std::unique_ptr<Ball>( new Ball() ) );
  balls.push_back( std::unique_ptr<Ball>( new Ball("red") ) );
  balls.push_back( std::unique_ptr<Ball>( new BouncyBall() ) );
  
  for(auto ball = balls.begin(); ball != balls.end(); ball++) 
  {
    std::cout << (*ball)->getColor() << std::endl;
  }
  
  
  Command* move_command = new MoveCommand();
  
  move_command->execute(balls);
  
 // std::cout << ball->getColor() << std::endl;
 // std::cout << (*red_ball).getColor() << std::endl;
  
  //std::cout << b_ball->getColor() << std::endl;
 // delete ball;
 // delete red_ball;
  
  return 0;
}