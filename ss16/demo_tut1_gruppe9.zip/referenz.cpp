/*
Beschreibung:
nun wird statt einer Referenz ein Pointer verwendet, gleiches verhalten
*/


#include <iostream>

void funcValue(int &x, int val)
{
  x += val;
}

int main()
{
  int v = 3;
  funcValue(v, 4);
  std::cout << v << std::endl;
  
  return 0;
}
