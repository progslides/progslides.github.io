#ifndef SEP_SAFE_H
#define SEP_SAFE_H

#include <vector>
#include <iostream>
#include <memory>
namespace sep
{
  class Safe
  {
    private:
      static size_t safe_counter;
      const size_t safeId;
      std::vector<std::string> passwords;
      std::shared_ptr<std::string> masterPassword;
      //std::string *masterPassword = nullptr;
    public:
      Safe(std::string& masterPassword);
      ~Safe() noexcept;
      void savePassword(std::string const& password);
      void printPasswords(std::string const& masterPassword) const;
  };
}
#endif //SEP_SAFE_H
