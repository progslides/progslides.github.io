#include <iostream>
#include <string>
#include "Person.h"

int main()
{
  Person alice("alice");
  Person bob;
  
  alice.printData();
  bob.printData();
  
  std::cout << "set data" << std::endl;
  
  alice.setAge(20);
  alice.setFunction("student");
  std::cout << "Age of Alice: " << alice.getAge() << std::endl;
  
  return 0;
}
