/*
Experimente mit const
*/
#include <iostream>
int main()
{
  //Konstante, nachtraegliches aendern des Wertes nicht moeglich!
  const int value = 3; 
  std::cout << value << std::endl;
  value = 5;
  std::cout << value << std::endl;
  
  
  //Pointer auf Konstante, gleich wie oben, Wert darf nicht veraendert werden
  int x = 30;
  const int *pointer = &x; //Pointer auf Konstante
  *pointer = 20;
 
  //------------------//
  
  //Wir wollen die Adresse eines Pointers aendern, hier moeglich
  int y = 30;
  int *ptr = &y
  int k = 50;
  ptr = &k;
  std::cout << *ptr << std::endl;
  
  
  //Konstanter Pointer auf Variable, Adresse kann nicht mehr geaendert werden
  int y = 30;
  int *const ptr = &y;
  int k = 50;
  ptr = &k;
  std::cout << *ptr << std::endl;

  return 0;
}
