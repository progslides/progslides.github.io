#ifndef MOVECOMMAND
#define MOVECOMMAND
#include <vector>
#include "Command.h"
class MoveCommand : public Command
{
  public:
    MoveCommand() : Command("MoveCommand!"){}
    virtual ~MoveCommand();

    virtual int execute(std::vector<std::unique_ptr<Ball> >& params);
};
#endif