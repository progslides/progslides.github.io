#include "SaferSafe.h"
#include "InvalidPasswordException.h"

SaferSafe::SaferSafe(std::string& masterPassword)
  : Safe(masterPassword)
{

}


void SaferSafe::savePassword(std::string const& password)
{
  if (password.length() < 10)
  {
    throw InvalidPasswordException(password, 10);
  }

  Safe::savePassword(password);
}
