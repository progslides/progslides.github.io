// Person.cpp
#include <iostream>
#include "Person.h"


Person::Person(std::string name) : name_(name), function_("none"), 
  mail_("none"), age_(0)
{

}

Person::Person() : name_("none"), function_("none"), 
  mail_("none"), age_(0)
{

}

void Person::printData()
{
  std::cout << "Name: " << name_ << " Age: " << age_ << " Function: " 
    << function_ << " E-Mail: " << mail_ << std::endl;
}

std::string Person::getName()
{
  return name_;
}

std::string Person::getFunction()
{
  return function_;
}

std::string Person::getMail()
{
  return mail_;
}

int Person::getAge()
{
  return age_;
}


void Person::setName(std::string new_name)
{
  name_ = new_name;
}

void Person::setFunction(std::string new_function)
{
  function_ = new_function;
}

void Person::setMail(std::string new_mail)
{
  mail_ = new_mail;
}

void Person::setAge(int new_age)
{
  age_ = new_age;
}

Person::~Person()
{

}
   
