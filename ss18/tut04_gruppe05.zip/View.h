#ifndef VIEW_H
#define VIEW_H

#include <string>
#include <vector>
#include <fstream>
class View
{
public:
	virtual void outputMessage(std::string& message);
	std::vector<std::string> parseArgsWithPrompt();
};


class FileOutputView : public View
{
public:
	FileOutputView(std::string filename);
	virtual void outputMessage(std::string& message);
private:
	std::fstream file_;
};

#endif