#ifndef CONTROLLER_H
#define CONTROLLER_H

#include <memory>
#include <string>
#include <map>
class Model;
class View;
#include "Command.h"

class Controller
{
public:
	Controller(std::unique_ptr<View> view, std::unique_ptr<Model> model);
	void run();
	void quit();
	
	void outputToView(std::string output);
	void setPassword(std::string new_password);
	std::string getPassword();
	//TODO: implement behaviour of application
private:

	std::map< std::string, std::unique_ptr<Command> > command_map_;
	std::unique_ptr<View> view_;
	std::unique_ptr<Model> model_;
	bool running_;
	void initCommands();
};

#endif