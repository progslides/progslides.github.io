#include "View.h"
#include "Model.h"
#include "Controller.h"
#include <iostream>
#include <memory>

int main()
{
	//TODO: assemble model, view, controller and run the app

	std::unique_ptr<FileOutputView> view = std::unique_ptr<FileOutputView>(new FileOutputView("test.txt"));
	std::unique_ptr<Model> model = std::unique_ptr<Model>(new Model());

	Controller controller(std::move(view), std::move(model));


	controller.run();




    return 0;
}

