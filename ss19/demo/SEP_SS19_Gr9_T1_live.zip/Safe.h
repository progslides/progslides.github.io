#ifndef SEP_SAFE_H
#define SEP_SAFE_H

#include <iostream>

class Safe{
  private:
    std::string password;
    int pin;
  public:
    Safe(int pin);
    void savePassword(std::string password);
    std::string getPassword(int pin) const;
};

#endif //SEP_SAFE_H
