// Ball.h
#ifndef BALL_H_INCLUDED
#define BALL_H_INCLUDED
#include <string>
class Ball
{
protected:
  std::string color_;
  double x_, y_;
  int* memory;

public:
  
  Ball(std::string color);
  Ball();
  virtual void move(double dx, double dy);
  virtual ~Ball();
  std::string getColor();
  void setColor(std::string new_color);
};
#endif